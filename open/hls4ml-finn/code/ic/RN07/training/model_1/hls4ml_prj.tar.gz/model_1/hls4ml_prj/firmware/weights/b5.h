//Numpy array shape [4]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 4

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
bias5_t b5[4];
#else
bias5_t b5[4] = {0.15625, 0.09375, 0.46875, 0.37500};
#endif

#endif
