//Numpy array shape [10]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 10

#ifndef B18_H_
#define B18_H_

#ifndef __SYNTHESIS__
bias18_t b18[10];
#else
bias18_t b18[10] = {0.00000, 0.00000, 0.00000, 0.00000, 0.00000, 0.00000, 0.00000, 0.00000, 0.00000, 0.00000};
#endif

#endif
